@start "" "Tom and Jerry - War of the Whiskers.exe"
