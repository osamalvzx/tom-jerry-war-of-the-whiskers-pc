How to create a mod:
1. Put your replaced files here matching the game directory structure (such as GFX/CAST/TOM/tom.XBD)
2. Enable this mod in the in-game MODS CONFIG menu!
